package com.example.aiinfluencer;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(16,19,15), panel=Color.rgb(28,32,25), lime=Color.rgb(211,239,126), muted=Color.rgb(166,175,154);
    LinearLayout root, content;
    ImageView reference;
    Uri referenceUri;
    EditText name, bio, identity, scene;
    TextView prompt, status;
    String chosenScene="Gym training session";
    final int PICK_IMAGE=41;

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    GradientDrawable shape(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
    void space(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    EditText edit(String hint,String value,int lines){EditText e=new EditText(this);e.setText(value);e.setHint(hint);e.setTextColor(Color.WHITE);e.setHintTextColor(muted);e.setTextSize(14);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(shape(Color.rgb(17,21,16),Color.rgb(65,76,54)));e.setMinLines(lines);e.setGravity(Gravity.TOP);return e;}
    Button button(String label, boolean primary){Button b=new Button(this);b.setText(label);b.setTextColor(primary?Color.rgb(22,29,14):Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setBackground(shape(primary?lime:Color.rgb(48,57,39),primary?lime:Color.rgb(82,101,57)));return b;}
    void label(LinearLayout l,String s){TextView t=text(s,12,muted,true);l.addView(t);space(l,6);}
    LinearLayout card(){LinearLayout c=vertical();c.setPadding(dp(16),dp(16),dp(16),dp(16));c.setBackground(shape(panel,Color.rgb(52,61,44)));return c;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);build();}
    void build(){
        ScrollView scroll=new ScrollView(this);root=vertical();root.setBackgroundColor(bg);root.setPadding(dp(18),dp(18),dp(18),dp(24));scroll.addView(root);setContentView(scroll);
        TextView brand=text("✦  AI INFLUENCER STUDIO",17,Color.WHITE,true);root.addView(brand);space(root,24);
        TextView eyebrow=text("YOUR VIRTUAL CREATOR",10,lime,true);root.addView(eyebrow);space(root,5);
        TextView title=text("One identity.\nEndless stories.",34,Color.WHITE,true);root.addView(title);space(root,8);
        TextView intro=text("Create a fictional adult fitness & lifestyle influencer and plan consistent photoshoots.",14,muted,false);root.addView(intro);space(root,22);

        LinearLayout c=card();root.addView(c);
        c.addView(text("01 — CHARACTER IDENTITY",11,lime,true));space(c,12);
        label(c,"CHARACTER NAME");name=edit("Name","Elena Hart",1);c.addView(name);space(c,12);
        label(c,"BIO");bio=edit("Short creator bio","A fictional adult fitness and lifestyle creator sharing training, everyday routines and travel.",3);c.addView(bio);space(c,12);
        label(c,"VISUAL IDENTITY NOTES");identity=edit("Describe her appearance","Fictional adult European woman, natural skin texture, medium brown hair, hazel eyes, friendly confident expression, understated makeup. Preserve facial structure and distinguishing features from the reference image.",5);c.addView(identity);space(c,12);
        reference=new ImageView(this);reference.setAdjustViewBounds(true);reference.setScaleType(ImageView.ScaleType.CENTER_CROP);reference.setBackground(shape(Color.rgb(17,21,16),0));c.addView(reference,new LinearLayout.LayoutParams(-1,dp(170)));
        Button upload=button("＋  Upload character reference",false);c.addView(upload);upload.setOnClickListener(v->pickImage());space(c,8);
        Button save=button("Save character profile",true);c.addView(save);save.setOnClickListener(v->{getPreferences(0).edit().putString("name",name.getText().toString()).putString("bio",bio.getText().toString()).putString("identity",identity.getText().toString()).apply();toast("Character profile saved on this phone.");});

        space(root,16);LinearLayout p=card();root.addView(p);
        p.addView(text("02 — PHOTO SHOOT",11,lime,true));space(p,12);
        label(p,"CHOOSE A SCENE");
        String[] scenes={"Gym training session","Outdoor morning run","Healthy cafe lifestyle","Travel and wellness editorial","At-home wellness routine"};
        Spinner spinner=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,scenes);spinner.setAdapter(adapter);p.addView(spinner);spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){chosenScene=scenes[pos];refreshPrompt();}});
        space(p,12);label(p,"SCENE DETAILS");scene=edit("Describe the shot","Candid editorial photograph, natural window light, realistic camera detail, tasteful athletic clothing.",3);p.addView(scene);scene.addTextChangedListener(watcher());
        space(p,12);Button preview=button("Build identity-preserving prompt",true);p.addView(preview);preview.setOnClickListener(v->refreshPrompt());
        space(p,12);prompt=text("",12,Color.WHITE,false);prompt.setPadding(dp(12),dp(12),dp(12),dp(12));prompt.setBackground(shape(Color.rgb(17,21,16),Color.rgb(65,76,54)));p.addView(prompt);
        space(root,8);status=text("Image generation is not connected yet. Add an image provider that supports reference-image conditioning to generate actual photos.",11,muted,false);root.addView(status);
        space(root,16);LinearLayout g=card();root.addView(g);g.addView(text("03 — YOUR GALLERY",11,lime,true));space(g,10);g.addView(text("Your generated images will appear here after an image-generation service is connected.",13,muted,false));
        loadProfile();refreshPrompt();
    }
    TextWatcher watcher(){return new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refreshPrompt();}public void afterTextChanged(Editable e){}};}
    void refreshPrompt(){if(prompt==null||name==null||identity==null||scene==null)return;String p="Use the uploaded reference image as the identity anchor. Preserve the same fictional adult woman's facial identity, face shape, eyes, nose, lips, skin tone and hair. Character: "+name.getText()+". Identity: "+identity.getText()+". Scene: "+chosenScene+". Details: "+scene.getText()+". Photorealistic lifestyle editorial, natural anatomy, realistic skin texture and believable lighting. Clearly fictional AI-generated adult character.";prompt.setText(p);}
    void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,PICK_IMAGE);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK_IMAGE&&c==RESULT_OK&&d!=null){referenceUri=d.getData();try{getContentResolver().takePersistableUriPermission(referenceUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception e){}reference.setImageURI(referenceUri);toast("Reference image selected.");}}
    void loadProfile(){android.content.SharedPreferences p=getPreferences(0);name.setText(p.getString("name","Elena Hart"));bio.setText(p.getString("bio","A fictional adult fitness and lifestyle creator sharing training, everyday routines and travel."));identity.setText(p.getString("identity",identity.getText().toString()));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}