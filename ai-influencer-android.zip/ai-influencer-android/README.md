# AI Influencer Studio — Android project

This is a native Android Studio starter app for an original fictional adult fitness/lifestyle virtual influencer.

## Open it
1. Download and unzip this folder on a computer.
2. Install Android Studio.
3. Choose **Open** and select this folder.
4. Let Gradle sync, then press Run with an Android phone connected or an emulator selected.

## Important
This is an Android source project, not an installable APK. An APK must be built with Android Studio/Gradle. Actual image generation is not connected; integrate a server-side image provider with reference-image conditioning before using the photo generation workflow. Never put provider API keys in the app. Reference-image conditioning can improve consistency but cannot guarantee a perfectly identical face.
